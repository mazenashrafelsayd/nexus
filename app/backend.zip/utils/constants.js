module.exports = {
    paginate: 20,
    mongoUrl: 'mongodb://localhost:27017/boilerplate2'
};
